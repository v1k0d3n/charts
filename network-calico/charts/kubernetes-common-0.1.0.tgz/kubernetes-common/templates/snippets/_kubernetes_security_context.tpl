{{/*
Copyright 2018 Kubernetes/Flagship and it's Authors.
 Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
 Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/}}

{{/*
abstract: |
  Renders a security context for the pod.

values: |
security:
  security_context:
    enabled: true
    runAsUser: 999
    fsGroup: 999
  mongodb:
    security_context:
      fsGroup: 999
      runAsUser: 999
      allowPrivilegeEscalation: false
      capabilities:
        add: ["NET_ADMIN", "SYS_TIME"]
      seLinuxOptions:
        level: "s0:c123,c456"

usage: |
{{ dict "envAll" . | include "kubernetes-common.snippets.security-context-pod" }}

return: |
securityContext:
  enabled: true
  fsGroup: 999
  runAsUser: 999

*/}}

{{- define "kubernetes-common.snippets.security-context-pod" -}}
{{- $envAll := index . "envAll" }}
  {{- if $envAll.Values.security.security_context.enabled -}}
securityContext:
{{ toYaml $envAll.Values.security.security_context | indent 2 }}
  {{- end}}
{{- end -}}

{{/*
abstract: |
  Renders a security context for a given container.

values: |
security:
  security_context:
    enabled: true
    runAsUser: 999
    fsGroup: 999
  mongodb:
    security_context:
      fsGroup: 999
      runAsUser: 999
      allowPrivilegeEscalation: false
      capabilities:
        add: ["NET_ADMIN", "SYS_TIME"]
      seLinuxOptions:
        level: "s0:c123,c456"

usage: |
{{ dict "envAll" . "container" "mongodb" | include "kubernetes-common.snippets.security-context-container" }}

return: |
securityContext:
  allowPrivilegeEscalation: false
  capabilities:
    add:
    - NET_ADMIN
    - SYS_TIME
  fsGroup: 999
  runAsUser: 999
  seLinuxOptions:
    level: s0:c123,c456

*/}}

{{- define "kubernetes-common.snippets.security-context-container" -}}
{{- $envAll := index . "envAll" }}
{{- $container := index . "container" }}
  {{- if $envAll.Values.security.security_context.enabled -}}
securityContext:
{{ toYaml (index $envAll.Values.security $container "security_context") | indent 2 }}
  {{- end}}
{{- end -}}
